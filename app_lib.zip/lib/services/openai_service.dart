import 'dart:convert';

import 'package:http/http.dart' as http;

class OpenAIService {
  final String apiKey;
  final String baseUrl;

  OpenAIService({required this.apiKey, this.baseUrl = 'https://api.openai.com/v1'});

  Future<String> askAssistant({required String prompt, String? system}) async {
    final uri = Uri.parse('$baseUrl/chat/completions');
    final response = await http.post(
      uri,
      headers: {
        'Authorization': 'Bearer $apiKey',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'model': 'gpt-4o-mini',
        'messages': [
          if (system != null) {'role': 'system', 'content': system},
          {'role': 'user', 'content': prompt},
        ],
        'temperature': 0.2,
      }),
    );
    if (response.statusCode >= 200 && response.statusCode < 300) {
      final Map<String, dynamic> data = jsonDecode(response.body) as Map<String, dynamic>;
      final List choices = (data['choices'] as List?) ?? const [];
      if (choices.isNotEmpty) {
        final Map<String, dynamic> msg = choices.first['message'] as Map<String, dynamic>;
        return msg['content'] as String? ?? '';
      }
      return '';
    }
    throw Exception('OpenAI error ${response.statusCode}: ${response.body}');
  }
}


